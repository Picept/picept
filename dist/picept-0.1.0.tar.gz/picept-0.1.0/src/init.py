"""Picept initialization"""

from typing import Optional, List, Any
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from .context import PiceptScope, set_context
from .tracing.tracer import PiceptAttributesSpanProcessor

def init(
    trace_id: Optional[str] = None,
    experiment_id: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    config_id: Optional[str] = None,
    context_id: Optional[str] = None,
    endpoint: str = "http://localhost:4317",
    api_key: Optional[str] = None,
    integrations: Optional[List[Any]] = None,
) -> None:
    """
    Initialize Picept tracing
    
    Args:
        trace_id: Project name identifier
        experiment_id: Experiment identifier  
        user_id: User identifier
        session_id: Session identifier
        config_id: Configuration identifier
        context_id: Context identifier
        endpoint: OTLP endpoint for traces
        api_key: API key for authentication
        integrations: List of OpenTelemetry instrumentors
    """
    # Create context
    scope = PiceptScope(
        trace_id=trace_id,
        experiment_id=experiment_id,
        user_id=user_id,
        session_id=session_id,
        config_id=config_id,
        context_id=context_id,
    )
    set_context(scope)
    
    # Setup OpenTelemetry
    provider = TracerProvider()
    
    # Add our custom span processor
    provider.add_span_processor(PiceptAttributesSpanProcessor(scope))
    
    # Add OTLP exporter if endpoint provided
    if endpoint:
        headers = {}
        if api_key:
            headers["x-api-key"] = api_key
            
        exporter = OTLPSpanExporter(endpoint=endpoint, headers=headers, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
    
    trace.set_tracer_provider(provider)
    
    # Apply integrations
    if integrations:
        for integration in integrations:
            if hasattr(integration, 'instrument'):
                integration.instrument()

    print(f"✅ Picept initialized with context: {scope}")

    