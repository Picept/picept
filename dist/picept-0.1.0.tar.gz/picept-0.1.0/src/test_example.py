"""Test script to verify Picept functionality"""

import picept
from openinference.instrumentation.langchain import LangChainInstrumentor
from opentelemetry.instrumentation.threading import ThreadingInstrumentor
from opentelemetry.instrumentation.asyncio import AsyncioInstrumentor

# Initialize Picept (exactly like Patronus)
picept.init(
    trace_id="test-project",
    experiment_id="exp-123", 
    user_id="user-456",
    session_id="session-789",
    config_id="config-abc",
    context_id="context-xyz",
    endpoint="http://localhost:4317",  # Your OTLP collector
    integrations=[
        LangChainInstrumentor(),
        ThreadingInstrumentor(),
        AsyncioInstrumentor()
    ]
)

# Test basic tracing
@picept.traced()
def simple_function(input_text):
    """Test function with tracing"""
    return f"Processed: {input_text}"

@picept.traced()
def complex_workflow():
    """Test complex workflow with nested spans"""
    
    with picept.start_span("Data preparation"):
        data = "raw data"
        processed_data = data.upper()
    
    with picept.start_span("Processing"):
        result = simple_function(processed_data)
    
    with picept.start_span("Finalization"):
        final_result = f"Final: {result}"
    
    return final_result

if __name__ == "__main__":
    print("🧪 Testing Picept tracing...")
    
    # Test basic function
    result1 = simple_function("hello world")
    print(f"Result 1: {result1}")
    
    # Test complex workflow
    result2 = complex_workflow()
    print(f"Result 2: {result2}")
    
    print("✅ Picept test completed!")